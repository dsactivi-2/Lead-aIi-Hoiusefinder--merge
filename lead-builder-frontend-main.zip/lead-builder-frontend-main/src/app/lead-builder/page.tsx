// Route alias: /lead-builder -> same content as /
export { default } from "../page"
